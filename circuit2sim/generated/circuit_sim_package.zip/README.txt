================================================================================
Circuit2Sim - Generated Simulation Model Package
Project Name : Benchmark: Rc Filter (ID: a4d0a414)
Model Name   : circuit_sim
Target       : MATLAB / Simscape Electrical / SPICE
Generated    : 2026-09-24 18:38:33 UTC
================================================================================

PACKAGE CONTENTS:
1. circuit_sim.slx
   - Native Simscape Electrical model file.
   - Open and simulate directly in MATLAB/Simulink (R2023a or newer).
   - Command: open_system('circuit_sim'); sim('circuit_sim');

2. generate_circuit_sim.m
   - Standalone MATLAB automation script.
   - Reconstructs and auto-wires the complete Simscape physical network.
   - Command: run('generate_circuit_sim.m');

3. circuit_sim.cir
   - Standard SPICE netlist.
   - Load into LTspice, NGSpice, or any SPICE-compatible electrical simulator.

4. circuit_ir_a4d0a414.json
   - Universal Circuit Intermediate Representation.
   - Contains normalized component parameters, net connections, and pin coordinates.

5. validation_report.json
   - Electrical Rule Check (ERC) and simulation readiness validation diagnostics.

================================================================================
